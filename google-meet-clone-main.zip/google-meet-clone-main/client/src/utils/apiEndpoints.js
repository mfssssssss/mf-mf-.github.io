export const BASE_URL = "http://localhost:4000";
export const SAVE_CALL_ID = "/api/save-call-id";
export const GET_CALL_ID = "/api/get-call-id";
